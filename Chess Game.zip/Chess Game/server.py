import socket
import threading
import json
import time
import uuid
import chess

SERVER_IP = '0.0.0.0'
SERVER_PORT = 9999
BUFFER_SIZE = 4096
MAX_PLAYERS = 100
TURN_TIME_LIMIT = 600

clients = {}
lobbies = {}
games = {}
waiting_players = []
spectators = {}

lock = threading.Lock()

def find_game_by_player(client_socket):
    for game_id, game in games.items():
        if client_socket in game['players'].values():
            return game_id, game
    return None, None

def find_game_by_spectator(client_socket):
     for game_id, game_spectators in spectators.items():
         if client_socket in game_spectators:
             return game_id, games.get(game_id)
     return None, None

def broadcast(message, game_id, exclude_socket=None):
    game = games.get(game_id)
    if not game:
        return

    player_sockets = list(game['players'].values())
    spec_sockets = spectators.get(game_id, [])
    all_sockets = player_sockets + spec_sockets

    for sock in all_sockets:
        if sock != exclude_socket:
            try:
                sock.send((json.dumps(message) + '\n').encode('utf-8'))
            except socket.error as e:
                print(f"Error sending message to a socket: {e}")


def send_to_socket(client_socket, message):
    try:
        client_socket.send((json.dumps(message) + '\n').encode('utf-8'))
    except socket.error as e:
        print(f"Error sending direct message: {e}")
        handle_disconnect(client_socket)


def handle_disconnect(client_socket):
    with lock:
        username = clients.pop(client_socket, None)
        if not username:
            return

        print(f"Client {username} disconnected.")

        if client_socket in waiting_players:
            waiting_players.remove(client_socket)
            print(f"{username} removed from waiting lobby.")

        game_id, game = find_game_by_player(client_socket)
        if game:
            opponent_socket = None
            disconnected_color = None
            for color, sock in game['players'].items():
                if sock == client_socket:
                    disconnected_color = color
                else:
                    opponent_socket = sock

            winner = "black" if disconnected_color == "white" else "white"
            result_message = {
                'type': 'game_over',
                'game_id': game_id,
                'result': 'disconnect',
                'winner': winner,
                'reason': f'{username} disconnected.'
            }
            if opponent_socket:
                 send_to_socket(opponent_socket, result_message)

            broadcast({'type': 'chat_update', 'sender': 'System', 'text': f'{username} disconnected. Game over.'}, game_id)
            broadcast(result_message, game_id)

            del games[game_id]
            if game_id in spectators:
                del spectators[game_id]
            print(f"Game {game_id} ended due to disconnect.")

        game_id_spec, _ = find_game_by_spectator(client_socket)
        if game_id_spec and game_id_spec in spectators:
            spectators[game_id_spec].remove(client_socket)
            if not spectators[game_id_spec]:
                del spectators[game_id_spec]
            print(f"{username} stopped spectating game {game_id_spec}.")

        try:
            client_socket.close()
        except socket.error:
            pass


def validate_move(board, move_uci, player_color):
    current_turn_color = "white" if board.turn == chess.WHITE else "black"
    if player_color != current_turn_color:
        return False, "Not your turn."

    try:
        move = board.parse_uci(move_uci)
        if move in board.legal_moves:
            return True, "Move is legal."
        else:
            return False, "Illegal move."
    except ValueError:
        return False, "Invalid move format."


def check_game_over(board):
    if board.is_checkmate():
        winner = "black" if board.turn == chess.WHITE else "white"
        return True, "checkmate", winner, f"Checkmate! {winner.capitalize()} wins."
    if board.is_stalemate():
        return True, "stalemate", None, "Stalemate! It's a draw."
    if board.is_insufficient_material():
        return True, "draw", None, "Draw due to insufficient material."
    if board.can_claim_draw():
         return True, "draw", None, "Draw can be claimed (e.g., threefold repetition)."
    return False, None, None, None


def start_game_timer(game_id):
    game = games.get(game_id)
    if not game or game.get('timer_thread_running'):
        return

    game['timer_thread_running'] = True

    def timer_loop():
        while game_id in games:
            time.sleep(1)
            with lock:
                current_game = games.get(game_id)
                if not current_game or current_game['board'].is_game_over(claim_draw=True):
                    current_game['timer_thread_running'] = False
                    break

                current_turn_color = "white" if current_game['board'].turn == chess.WHITE else "black"
                timer_key = f'time_{current_turn_color}'

                current_game[timer_key] -= 1
                current_game['last_update_time'] = time.time()

                if current_game[timer_key] <= 0:
                    winner = "black" if current_turn_color == "white" else "white"
                    reason = f"{current_turn_color.capitalize()} ran out of time."
                    game_over_message = {
                        'type': 'game_over',
                        'game_id': game_id,
                        'result': 'timeout',
                        'winner': winner,
                        'reason': reason
                    }
                    broadcast(game_over_message, game_id)
                    if game_id in games: del games[game_id]
                    if game_id in spectators: del spectators[game_id]
                    print(f"Game {game_id} ended due to timeout.")
                    break

                if int(time.time()) % 5 == 0:
                    time_update_message = {
                        'type': 'time_update',
                        'game_id': game_id,
                        'time_white': current_game['time_white'],
                        'time_black': current_game['time_black'],
                    }
                    broadcast(time_update_message, game_id)
                    time.sleep(0.2)

        print(f"Timer thread for game {game_id} stopped.")


    timer_thread = threading.Thread(target=timer_loop, daemon=True)
    timer_thread.start()


def handle_move(client_socket, message):
    game_id = message.get('game_id')
    move_uci = message.get('move')
    game = games.get(game_id)
    
    if not game:
        send_to_socket(client_socket, {'type': 'error', 'message': 'Game not found'})
        return
        
    player_color = None
    for color, sock in game['players'].items():
        if sock == client_socket:
            player_color = color
            
    is_valid, reason = validate_move(game['board'], move_uci, player_color)
    if not is_valid:
        send_to_socket(client_socket, {'type': 'error', 'message': f'Invalid move: {reason}'})
        return
    
    try:
        move = chess.Move.from_uci(move_uci)
        game['board'].push(move)
        game['last_move'] = move_uci
        
        game['turn'] = 'black' if player_color == 'white' else 'white'
        
        game_over_result = check_game_over(game['board'])
        
        board_fen = game['board'].fen()
        turn_color = 'white' if game['board'].turn == chess.WHITE else 'black'
        
        update_message = {
            'type': 'game_update',
            'game_id': game_id,
            'board_fen': board_fen,
            'turn': turn_color,
            'last_move': move_uci,
            'is_check': game['board'].is_check()
        }
        
        print(f"Broadcasting update: {update_message}")
        broadcast(update_message, game_id)
        
        if game_over_result:
            broadcast(game_over_result, game_id)
            
    except Exception as e:
        print(f"Error processing move: {e}")
        send_to_socket(client_socket, {'type': 'error', 'message': f'Error: {str(e)}'})
        return


def handle_client(client_socket):
    username = None
    try:
        while True:
            message_bytes = client_socket.recv(BUFFER_SIZE)
            if not message_bytes:
                break

            message_str = message_bytes.decode('utf-8')
            for msg_part in message_str.strip().split('\n'):
                 if not msg_part: continue
                 try:
                     message = json.loads(msg_part)
                     print(f"Received from {clients.get(client_socket, 'Unknown')}: {message}")

                     msg_type = message.get('type')

                     with lock:
                         if msg_type == 'login':
                             temp_username = message.get('username')
                             if temp_username and temp_username not in clients.values():
                                 username = temp_username
                                 clients[client_socket] = username
                                 send_to_socket(client_socket, {'type': 'login_success', 'username': username})
                                 print(f"User {username} logged in.")
                                 available_games = [
                                     {"id": gid, "players": [clients.get(p) for p in g['players'].values()]}
                                     for gid, g in games.items() if len(g['players']) == 2
                                 ]
                                 send_to_socket(client_socket, {'type': 'game_list', 'games': available_games})

                             else:
                                 send_to_socket(client_socket, {'type': 'error', 'message': 'Username invalid or already taken.'})

                         elif msg_type == 'join_lobby':
                             if client_socket not in clients:
                                 send_to_socket(client_socket, {'type': 'error', 'message': 'Please login first.'})
                                 continue

                             current_game_id, _ = find_game_by_player(client_socket)
                             if current_game_id:
                                 send_to_socket(client_socket, {'type': 'error', 'message': 'Already in a game.'})
                                 continue

                             if client_socket in waiting_players:
                                 send_to_socket(client_socket, {'type': 'info', 'message': 'Already waiting in lobby.'})
                                 continue

                             waiting_players.append(client_socket)
                             send_to_socket(client_socket, {'type': 'lobby_joined'})
                             print(f"{clients[client_socket]} joined the lobby.")

                             if len(waiting_players) >= 2:
                                 player1_socket = waiting_players.pop(0)
                                 player2_socket = waiting_players.pop(0)
                                 player1_name = clients[player1_socket]
                                 player2_name = clients[player2_socket]

                                 game_id = str(uuid.uuid4())[:8]
                                 board = chess.Board()
                                 games[game_id] = {
                                     'board': board,
                                     'players': {'white': player1_socket, 'black': player2_socket},
                                     'player_names': {'white': player1_name, 'black': player2_name},
                                     'turn': 'white',
                                     'time_white': TURN_TIME_LIMIT,
                                     'time_black': TURN_TIME_LIMIT,
                                     'last_update_time': time.time(),
                                     'timer_thread_running': False
                                 }
                                 spectators[game_id] = []

                                 print(f"Starting game {game_id} between {player1_name} (White) and {player2_name} (Black)")

                                 game_start_msg_p1 = {
                                     'type': 'game_start',
                                     'game_id': game_id,
                                     'opponent': player2_name,
                                     'color': 'white',
                                     'board_fen': board.fen(),
                                     'time_white': TURN_TIME_LIMIT,
                                     'time_black': TURN_TIME_LIMIT
                                 }
                                 game_start_msg_p2 = {
                                     'type': 'game_start',
                                     'game_id': game_id,
                                     'opponent': player1_name,
                                     'color': 'black',
                                     'board_fen': board.fen(),
                                     'time_white': TURN_TIME_LIMIT,
                                     'time_black': TURN_TIME_LIMIT
                                 }

                                 send_to_socket(player1_socket, game_start_msg_p1)
                                 send_to_socket(player2_socket, game_start_msg_p2)
                                 start_game_timer(game_id)

                         elif msg_type == 'make_move':
                             handle_move(client_socket, message)

                         elif msg_type == 'chat_message':
                             text = message.get('text')
                             sender_name = clients.get(client_socket, 'Unknown')
                             game_id, _ = find_game_by_player(client_socket)
                             spec_game_id, _ = find_game_by_spectator(client_socket)

                             target_game_id = game_id or spec_game_id

                             if text and target_game_id:
                                 chat_update = {
                                     'type': 'chat_update',
                                     'sender': sender_name,
                                     'text': text
                                 }
                                 broadcast(chat_update, target_game_id, exclude_socket=None)
                             elif text:
                                 send_to_socket(client_socket, {'type': 'error', 'message': 'Cannot chat outside of a game.'})


                         elif msg_type == 'spectate_request':
                             game_id = message.get('game_id')
                             game = games.get(game_id)
                             player_name = clients.get(client_socket)

                             if not player_name:
                                  send_to_socket(client_socket, {'type': 'error', 'message': 'Please login first.'})
                                  continue

                             if not game:
                                 send_to_socket(client_socket, {'type': 'error', 'message': 'Game not found.'})
                                 continue

                             if client_socket in game['players'].values():
                                 send_to_socket(client_socket, {'type': 'error', 'message': 'You are playing in this game.'})
                                 continue

                             prev_game_id, _ = find_game_by_spectator(client_socket)
                             if prev_game_id and prev_game_id in spectators:
                                 spectators[prev_game_id].remove(client_socket)
                                 if not spectators[prev_game_id]: del spectators[prev_game_id]

                             if game_id not in spectators: spectators[game_id] = []
                             if client_socket not in spectators[game_id]:
                                 spectators[game_id].append(client_socket)

                             spectate_info = {
                                 'type': 'spectate_info',
                                 'game_id': game_id,
                                 'board_fen': game['board'].fen(),
                                 'turn': game['turn'],
                                 'players': list(game['player_names'].values()),
                                 'player_colors': game['player_names'],
                                 'time_white': int(game['time_white']),
                                 'time_black': int(game['time_black']),
                                 'is_check': game['board'].is_check(),
                                 'legal_moves': [m.uci() for m in game['board'].legal_moves]
                             }
                             send_to_socket(client_socket, spectate_info)
                             print(f"{player_name} started spectating game {game_id}")
                             broadcast({'type': 'chat_update', 'sender': 'System', 'text': f'{player_name} started spectating.'}, game_id)


                 except json.JSONDecodeError:
                     print(f"Invalid JSON received from {clients.get(client_socket, 'Unknown')}: {msg_part}")
                 except Exception as e:
                     print(f"Error processing message from {clients.get(client_socket, 'Unknown')}: {e}")
                     import traceback
                     traceback.print_exc()


    except socket.error as e:
        print(f"Socket error with {clients.get(client_socket, 'Unknown')}: {e}")
    except Exception as e:
         print(f"Unhandled exception in client handler for {clients.get(client_socket, 'Unknown')}: {e}")
         import traceback
         traceback.print_exc()
    finally:
        handle_disconnect(client_socket)


def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server_socket.bind((SERVER_IP, SERVER_PORT))
        server_socket.listen(MAX_PLAYERS)
        print(f"Server listening on {SERVER_IP}:{SERVER_PORT}")

        while True:
            client_socket, addr = server_socket.accept()
            print(f"Accepted connection from {addr}")
            client_thread = threading.Thread(target=handle_client, args=(client_socket,), daemon=True)
            client_thread.start()

    except OSError as e:
        print(f"Error binding or listening: {e}. Port likely in use.")
    except Exception as e:
        print(f"Server error: {e}")
    finally:
        print("Shutting down server.")
        server_socket.close()
        with lock:
            for sock in list(clients.keys()):
                 handle_disconnect(sock)


if __name__ == "__main__":
    start_server()
