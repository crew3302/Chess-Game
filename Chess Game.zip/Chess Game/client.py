import socket
import threading
import json
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox, scrolledtext
import chess
import chess.svg
from PIL import Image, ImageTk
import io
import time
import os

SERVER_IP = '127.0.0.1'
SERVER_PORT = 9999
BUFFER_SIZE = 4096
ASSETS_DIR = 'assets'

client_socket = None
username = None
root = None
login_frame = None
lobby_frame = None
game_frame = None
game_info = {}
gui_queue = None
network_thread = None
stop_network_thread = threading.Event()

selected_square = None
possible_moves = set()
piece_images = {}

def connect_to_server():
    global client_socket, network_thread
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((SERVER_IP, SERVER_PORT))
        stop_network_thread.clear()
        network_thread = threading.Thread(target=receive_messages, daemon=True)
        network_thread.start()
        return True
    except socket.error as e:
        messagebox.showerror("Connection Error", f"Could not connect to server: {e}")
        client_socket = None
        return False

def send_message(message):
    if client_socket:
        try:
            client_socket.sendall((json.dumps(message) + '\n').encode('utf-8'))
        except socket.error as e:
            handle_server_disconnect()
    else:
        handle_server_disconnect()

def receive_messages():
    global game_info
    buffer = ""
    while not stop_network_thread.is_set() and client_socket:
        try:
            data = client_socket.recv(BUFFER_SIZE)
            if not data:
                handle_server_disconnect()
                break
            buffer += data.decode('utf-8')
            while '\n' in buffer:
                message_str, buffer = buffer.split('\n', 1)
                if not message_str.strip():
                    continue
                try:
                    message = json.loads(message_str)
                    if gui_queue:
                        gui_queue.put(message)
                except json.JSONDecodeError:
                    try:
                        pos = 1
                        while pos < len(message_str):
                            if message_str[pos] == '{' and message_str[pos-1] == '}':
                                json1 = message_str[:pos]
                                json2 = message_str[pos:]
                                message1 = json.loads(json1)
                                if gui_queue:
                                    gui_queue.put(message1)
                                try:
                                    message2 = json.loads(json2)
                                    if gui_queue:
                                        gui_queue.put(message2)
                                except json.JSONDecodeError:
                                    buffer = json2 + buffer
                                break
                            pos += 1
                    except Exception:
                        pass
                except Exception:
                    pass
        except socket.error:
            if not stop_network_thread.is_set():
                handle_server_disconnect()
            break
        except Exception:
            handle_server_disconnect()
            break

def handle_server_disconnect():
    global client_socket, username, network_thread
    if client_socket:
        try:
            client_socket.close()
        except socket.error:
            pass
    client_socket = None
    username = None
    stop_network_thread.set()
    network_thread = None
    game_info = {}
    if root and gui_queue:
        gui_queue.put({'type': '_internal_disconnect'})

def process_gui_queue():
    global game_info, username
    try:
        while not gui_queue.empty():
            message = gui_queue.get_nowait()
            msg_type = message.get('type')
            if msg_type == 'login_success':
                username = message.get('username')
                show_lobby_frame()
            elif msg_type == 'error':
                messagebox.showerror("Server Error", message.get('message', 'Unknown error'))
            elif msg_type == 'info':
                messagebox.showinfo("Server Info", message.get('message', 'Info'))
            elif msg_type == 'lobby_joined':
                if lobby_frame: lobby_frame.update_status("Waiting for opponent...")
            elif msg_type == 'game_list':
                if lobby_frame: lobby_frame.update_game_list(message.get('games', []))
            elif msg_type == 'game_start':
                game_info = message
                game_info['board'] = chess.Board(message.get('board_fen'))
                if 'turn' not in game_info:
                    game_info['turn'] = 'white' if game_info['board'].turn else 'black'
                show_game_frame()
                if game_frame: game_frame.update_display()
            elif msg_type == 'game_update':
                game_info.update(message)
                if 'board_fen' in message:
                    game_info['board'] = chess.Board(message['board_fen'])
                    server_turn = message.get('turn')
                    board_turn = 'white' if game_info['board'].turn else 'black'
                    if server_turn and server_turn != board_turn:
                        pass
                if game_frame: game_frame.update_display()
            elif msg_type == 'time_update':
                if 'time_white' in message:
                    game_info['time_white'] = message.get('time_white')
                if 'time_black' in message:
                    game_info['time_black'] = message.get('time_black')
                if game_frame:
                    game_frame.update_timers(message.get('time_white'), message.get('time_black'))
            elif msg_type == 'chat_update':
                if game_frame: game_frame.add_chat_message(message.get('sender'), message.get('text'))
            elif msg_type == 'game_over':
                game_info.update(message)
                if game_frame: game_frame.update_display()
                winner = message.get('winner')
                reason = message.get('reason', 'Game ended.')
                result_msg = f"Game Over: {reason}"
                if winner:
                    result_msg += f"\nWinner: {winner.capitalize()}"
                messagebox.showinfo("Game Over", result_msg)
                show_lobby_frame()
            elif msg_type == 'spectate_info':
                game_info = message
                game_info['board'] = chess.Board(message.get('board_fen'))
                game_info['is_spectator'] = True
                show_game_frame()
                if game_frame: game_frame.update_display()
            elif msg_type == '_internal_disconnect':
                if game_frame or lobby_frame:
                    messagebox.showerror("Disconnected", "Lost connection to the server.")
                    show_login_frame()
    except queue.Empty:
        pass
    finally:
        if root:
            root.after(100, process_gui_queue)

def load_piece_images(size=40):
    global piece_images
    if not os.path.isdir(ASSETS_DIR):
        return False
    for piece_type in chess.PIECE_TYPES:
        for color in chess.COLORS:
            base_symbol = chess.piece_symbol(piece_type)
            piece_symbol = base_symbol.upper() if color == chess.WHITE else base_symbol.lower()
            color_char = 'w' if color == chess.WHITE else 'b'
            filename = f"{color_char}{base_symbol.lower()}.png"
            filepath = os.path.join(ASSETS_DIR, filename)
            try:
                img = Image.open(filepath)
                if img.mode != 'RGBA':
                    img = img.convert('RGBA')
                img = img.resize((size, size), Image.Resampling.LANCZOS)
                piece_images[piece_symbol] = ImageTk.PhotoImage(img)
            except FileNotFoundError:
                piece_images[piece_symbol] = None
            except Exception:
                piece_images[piece_symbol] = None
    return True

class LoginFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding="20")
        self.master = master
        master.title("Chess Login")
        master.geometry("300x200")
        center_window(master, 300, 200)
        ttk.Label(self, text="Enter Username:").pack(pady=5)
        self.username_entry = ttk.Entry(self)
        self.username_entry.pack(pady=5)
        self.username_entry.focus_set()
        self.username_entry.bind("<Return>", self.login)
        self.login_button = ttk.Button(self, text="Login", command=self.login)
        self.login_button.pack(pady=10)
        self.status_label = ttk.Label(self, text="")
        self.status_label.pack(pady=5)

    def login(self, event=None):
        uname = self.username_entry.get().strip()
        if not uname:
            self.status_label.config(text="Username cannot be empty.")
            return
        if not client_socket:
            if not connect_to_server():
                self.status_label.config(text="Connection failed.")
                return
        self.status_label.config(text="Logging in...")
        send_message({'type': 'login', 'username': uname})

class LobbyFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding="20")
        self.master = master
        master.title(f"Chess Lobby - {username}")
        master.geometry("500x400")
        center_window(master, 500, 400)
        self.status_label = ttk.Label(self, text="Welcome to the Lobby!", font=("Arial", 14))
        self.status_label.pack(pady=10)
        self.join_button = ttk.Button(self, text="Join Game Queue", command=self.join_lobby)
        self.join_button.pack(pady=10)
        ttk.Label(self, text="Available Games to Spectate:").pack(pady=(10, 0))
        self.games_listbox = tk.Listbox(self, height=8, width=50)
        self.games_listbox.pack(pady=5)
        self.games_listbox.bind("<Double-Button-1>", self.spectate_selected_game)
        self.spectate_button = ttk.Button(self, text="Spectate Selected Game", command=self.spectate_selected_game)
        self.spectate_button.pack(pady=5)
        self.available_games = []

    def join_lobby(self):
        self.status_label.config(text="Joining queue...")
        send_message({'type': 'join_lobby'})

    def update_status(self, text):
        self.status_label.config(text=text)

    def update_game_list(self, games_data):
        self.available_games = games_data
        self.games_listbox.delete(0, tk.END)
        for game in self.available_games:
            player_text = " vs ".join(filter(None, game.get('players', ['Unknown', 'Unknown'])))
            self.games_listbox.insert(tk.END, f"Game {game.get('id', '?')}: {player_text}")

    def spectate_selected_game(self, event=None):
        selection = self.games_listbox.curselection()
        if not selection:
            messagebox.showwarning("Spectate", "Please select a game from the list.")
            return
        selected_index = selection[0]
        if selected_index < len(self.available_games):
            game_id = self.available_games[selected_index].get('id')
            if game_id:
                send_message({'type': 'spectate_request', 'game_id': game_id})
            else:
                messagebox.showerror("Error", "Could not get game ID.")
        else:
            messagebox.showerror("Error", "Invalid selection index.")

class GameFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding="10")
        self.master = master
        master.title("Chess Game")
        win_width = 800
        win_height = 600
        master.geometry(f"{win_width}x{win_height}")
        center_window(master, win_width, win_height)
        self.images_loaded = load_piece_images(size=50)
        self.board_size = 400
        self.square_size = self.board_size // 8
        self.main_paned_window = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        self.main_paned_window.pack(fill=tk.BOTH, expand=True)
        self.board_canvas = tk.Canvas(self.main_paned_window, width=self.board_size, height=self.board_size, borderwidth=0, highlightthickness=0)
        self.main_paned_window.add(self.board_canvas, weight=1)
        self.board_canvas.bind("<Button-1>", self.on_square_click)
        self.right_panel = ttk.Frame(self.main_paned_window)
        self.main_paned_window.add(self.right_panel, weight=0)
        self.info_frame = ttk.LabelFrame(self.right_panel, text="Game Info")
        self.info_frame.pack(pady=10, padx=10, fill=tk.X)
        self.player_info_label = ttk.Label(self.info_frame, text="You: - | Opponent: -")
        self.player_info_label.pack(pady=2)
        self.turn_label = ttk.Label(self.info_frame, text="Turn: -", font=("Arial", 12, "bold"))
        self.turn_label.pack(pady=2)
        self.status_label = ttk.Label(self.info_frame, text="")
        self.status_label.pack(pady=2)
        self.timer_frame = ttk.LabelFrame(self.right_panel, text="Timers")
        self.timer_frame.pack(pady=5, padx=10, fill=tk.X)
        self.white_timer_label = ttk.Label(self.timer_frame, text="White: --:--")
        self.white_timer_label.pack(pady=2)
        self.black_timer_label = ttk.Label(self.timer_frame, text="Black: --:--")
        self.black_timer_label.pack(pady=2)
        self.chat_frame = ttk.LabelFrame(self.right_panel, text="Chat")
        self.chat_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
        self.chat_display = scrolledtext.ScrolledText(self.chat_frame, state='disabled', height=10, width=35, wrap=tk.WORD)
        self.chat_display.pack(pady=5, padx=5, fill=tk.BOTH, expand=True)
        self.chat_entry_frame = ttk.Frame(self.chat_frame)
        self.chat_entry_frame.pack(fill=tk.X, padx=5, pady=(0, 5))
        self.chat_entry = ttk.Entry(self.chat_entry_frame)
        self.chat_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.chat_entry.bind("<Return>", self.send_chat)
        self.send_chat_button = ttk.Button(self.chat_entry_frame, text="Send", command=self.send_chat)
        self.send_chat_button.pack(side=tk.RIGHT, padx=(5, 0))

    def format_time(self, seconds):
        if seconds < 0: seconds = 0
        mins, secs = divmod(int(seconds), 60)
        return f"{mins:02d}:{secs:02d}"

    def update_timers(self, time_white, time_black):
        if time_white is not None:
            self.white_timer_label.config(text=f"White: {self.format_time(time_white)}")
        if time_black is not None:
            self.black_timer_label.config(text=f"Black: {self.format_time(time_black)}")

    def update_display(self):
        global selected_square, possible_moves
        if not game_info or 'board' not in game_info:
            return
        board = game_info['board']
        is_spectator = game_info.get('is_spectator', False)
        my_color_str = game_info.get('color')
        my_color = chess.WHITE if my_color_str == 'white' else chess.BLACK if my_color_str == 'black' else None
        opponent_name = game_info.get('opponent', 'N/A') if not is_spectator else " vs ".join(game_info.get('players',[]))
        self.master.title(f"Chess Game - {username}{' (Spectator)' if is_spectator else ''}")
        if not is_spectator:
            self.player_info_label.config(text=f"You: {my_color_str.capitalize()} | Opponent: {opponent_name}")
        else:
            p_colors = game_info.get('player_colors', {})
            white_p = p_colors.get('white', 'White')
            black_p = p_colors.get('black', 'Black')
            self.player_info_label.config(text=f"Spectating: {white_p} (W) vs {black_p} (B)")
        turn_color = game_info.get('turn', 'white')
        self.turn_label.config(text=f"Turn: {turn_color.capitalize()}")
        if turn_color == my_color_str:
            self.turn_label.config(font=("Arial", 12, "bold"))
        else:
            self.turn_label.config(font=("Arial", 12))
        status_text = ""
        if game_info.get('is_check'):
            status_text = "Check!"
        if game_info.get('result'):
            status_text = f"Game Over: {game_info.get('reason', '')}"
            self.turn_label.config(text="Game Over")
        self.status_label.config(text=status_text)
        self.update_timers(game_info.get('time_white'), game_info.get('time_black'))
        self.board_canvas.delete("all")
        board_orientation = my_color if my_color is not None else chess.WHITE
        for rank in range(8):
            for file in range(8):
                sq = chess.square(file, rank)
                display_rank = rank if board_orientation == chess.BLACK else 7 - rank
                color = "#DDB88C" if (rank + file) % 2 != 0 else "#FFFACD"
                x1 = file * self.square_size
                y1 = display_rank * self.square_size
                x2 = x1 + self.square_size
                y2 = y1 + self.square_size
                self.board_canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="")
                if sq == selected_square:
                    self.board_canvas.create_rectangle(x1, y1, x2, y2, fill="", outline="blue", width=3)
                if sq in possible_moves:
                    center_x, center_y = x1 + self.square_size // 2, y1 + self.square_size // 2
                    radius = self.square_size // 6
                    move_fill = "#aaaaaa" if board.piece_at(sq) is None else ""
                    move_outline = "#555555" if board.piece_at(sq) is None else "red"
                    move_width = 1 if board.piece_at(sq) is None else 2
                    self.board_canvas.create_oval(center_x - radius, center_y - radius, center_x + radius, center_y + radius, fill=move_fill, outline=move_outline, width=move_width)
                piece = board.piece_at(sq)
                if piece:
                    piece_symbol = piece.symbol()
                    if self.images_loaded and piece_images.get(piece_symbol):
                        self.board_canvas.create_image(x1 + self.square_size // 2, y1 + self.square_size // 2, image=piece_images[piece_symbol])
                    else:
                        self.board_canvas.create_text(x1 + self.square_size // 2, y1 + self.square_size // 2, text=piece_symbol, font=("Arial", self.square_size // 2, "bold"))
        last_move_uci = game_info.get('last_move')
        if last_move_uci:
            try:
                move = chess.Move.from_uci(last_move_uci)
                for sq in [move.from_square, move.to_square]:
                    file, rank = chess.square_file(sq), chess.square_rank(sq)
                    display_rank = rank if board_orientation == chess.BLACK else 7 - rank
                    x1 = file * self.square_size
                    y1 = display_rank * self.square_size
                    self.board_canvas.create_rectangle(x1, y1, x1 + self.square_size, y1 + self.square_size, outline="yellow", width=2)
            except ValueError:
                pass

    def on_square_click(self, event):
        global selected_square, possible_moves
        if not game_info or 'board' not in game_info or game_info.get('is_spectator'):
            return
        board = game_info['board']
        my_color_str = game_info.get('color')
        server_turn = game_info.get('turn')
        if server_turn is None:
            server_turn = 'white' if board.turn else 'black'
        is_my_turn = (server_turn == my_color_str)
        if server_turn == 'white' and not board.turn:
            board.push(chess.Move.null())
        elif server_turn == 'black' and board.turn:
            board.push(chess.Move.null())
        if not is_my_turn or board.is_game_over(claim_draw=True):
            selected_square = None
            possible_moves = set()
            self.update_display()
            return
        file = event.x // self.square_size
        board_orientation = my_color_str
        display_rank = event.y // self.square_size
        rank = display_rank if board_orientation == 'black' else 7 - display_rank
        clicked_square = chess.square(file, rank)
        if selected_square is not None:
            move_uci = chess.Move(selected_square, clicked_square).uci()
            piece = board.piece_at(selected_square)
            if piece and piece.piece_type == chess.PAWN:
                if (my_color_str == 'white' and chess.square_rank(clicked_square) == 7) or \
                   (my_color_str == 'black' and chess.square_rank(clicked_square) == 0):
                    move_uci += 'q'
            move = None
            try:
                move = board.parse_uci(move_uci)
            except ValueError:
                pass
            if move in board.legal_moves:
                send_message({
                    'type': 'make_move',
                    'game_id': game_info['game_id'],
                    'move': move.uci()
                })
                selected_square = None
                possible_moves = set()
            else:
                new_piece = board.piece_at(clicked_square)
                if new_piece and new_piece.color == (my_color_str == 'white'):
                    selected_square = clicked_square
                    possible_moves = {move.to_square for move in board.legal_moves if move.from_square == selected_square}
                else:
                    selected_square = None
                    possible_moves = set()
            self.update_display()
        else:
            piece = board.piece_at(clicked_square)
            if piece and piece.color == (my_color_str == 'white'):
                selected_square = clicked_square
                possible_moves = {move.to_square for move in board.legal_moves if move.from_square == selected_square}
                self.update_display()

    def send_chat(self, event=None):
        message_text = self.chat_entry.get().strip()
        if message_text and game_info.get('game_id'):
            send_message({
                'type': 'chat_message',
                'game_id': game_info['game_id'],
                'text': message_text
            })
            self.chat_entry.delete(0, tk.END)
        elif not game_info.get('game_id'):
            self.add_chat_message("System", "Cannot chat outside of a game.")

    def add_chat_message(self, sender, text):
        self.chat_display.config(state='normal')
        self.chat_display.insert(tk.END, f"{sender}: {text}\n")
        self.chat_display.config(state='disabled')
        self.chat_display.see(tk.END)

def center_window(window, width, height):
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)
    window.geometry(f'{width}x{height}+{x}+{y}')

def clear_frame(frame):
    for widget in frame.winfo_children():
        widget.destroy()
    frame.pack_forget()

def show_login_frame():
    global login_frame, lobby_frame, game_frame
    if lobby_frame: clear_frame(lobby_frame); lobby_frame = None
    if game_frame: clear_frame(game_frame); game_frame = None
    if not login_frame:
        login_frame = LoginFrame(root)
        login_frame.pack(fill="both", expand=True)
    else:
        login_frame.username_entry.delete(0, tk.END)
        login_frame.status_label.config(text="")
        login_frame.pack(fill="both", expand=True)
        login_frame.username_entry.focus_set()

def show_lobby_frame():
    global login_frame, lobby_frame, game_frame
    if login_frame: clear_frame(login_frame); login_frame = None
    if game_frame: clear_frame(game_frame); game_frame = None
    lobby_frame = LobbyFrame(root)
    lobby_frame.pack(fill="both", expand=True)
    send_message({'type': 'request_game_list'})

def show_game_frame():
    global login_frame, lobby_frame, game_frame
    if login_frame: clear_frame(login_frame); login_frame = None
    if lobby_frame: clear_frame(lobby_frame); lobby_frame = None
    game_frame = GameFrame(root)
    game_frame.pack(fill="both", expand=True)

def on_closing():
    global stop_network_thread
    stop_network_thread.set()
    if client_socket:
        try:
            client_socket.shutdown(socket.SHUT_RDWR)
            client_socket.close()
        except socket.error:
            pass
    if network_thread and network_thread.is_alive():
        network_thread.join(timeout=1.0)
    root.destroy()

if __name__ == "__main__":
    import queue
    gui_queue = queue.Queue()
    root = tk.Tk()
    style = ttk.Style(root)
    try:
        style.theme_use('clam')
    except tk.TclError:
        pass
    root.protocol("WM_DELETE_WINDOW", on_closing)
    show_login_frame()
    root.after(100, process_gui_queue)
    root.mainloop()
